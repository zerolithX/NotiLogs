package com.botstoredata.notiflogger;

public class NotifItem {
    public long id;
    public String packageName;
    public String appLabel;
    public String title;
    public String text;
    public long timestamp;

    public NotifItem(long id, String packageName, String appLabel, String title, String text, long timestamp) {
        this.id = id;
        this.packageName = packageName;
        this.appLabel = appLabel;
        this.title = title;
        this.text = text;
        this.timestamp = timestamp;
    }
}
