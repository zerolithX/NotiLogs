package com.botstoredata.notiflogger;

import android.app.Notification;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Listens for notifications posted by any app on the device and logs
 * them (app, title, text, time) into the local SQLite database.
 * Requires the user to grant "Notification access" in system settings.
 */
public class NotifListenerService extends NotificationListenerService {

    public static final String ACTION_NOTIF_LOGGED = "com.botstoredata.notiflogger.NOTIF_LOGGED";

    private DbHelper dbHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        dbHelper = new DbHelper(this);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;

        // Skip our own notifications (e.g. export progress) if any are added later.
        if (getPackageName().equals(sbn.getPackageName())) return;

        String packageName = sbn.getPackageName();
        String appLabel = resolveAppLabel(packageName);

        Notification notification = sbn.getNotification();
        String title = "";
        String text = "";
        if (notification != null && notification.extras != null) {
            Bundle extras = notification.extras;
            CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence textCs = extras.getCharSequence(Notification.EXTRA_TEXT);
            if (titleCs != null) title = titleCs.toString();
            if (textCs != null) text = textCs.toString();
        }

        long timestamp = sbn.getPostTime();

        dbHelper.insert(packageName, appLabel, title, text, timestamp);

        // Tell MainActivity (if open) to refresh its list.
        Intent broadcast = new Intent(ACTION_NOTIF_LOGGED);
        broadcast.setPackage(getPackageName());
        sendBroadcast(broadcast);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Intentionally not deleting logged history when a notification
        // is dismissed on the device - this app keeps a permanent log.
    }

    private String resolveAppLabel(String packageName) {
        PackageManager pm = getPackageManager();
        try {
            ApplicationInfo appInfo = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(appInfo).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName;
        }
    }
}
