package com.botstoredata.notiflogger;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "notiflogger.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE = "notifications";
    public static final String COL_ID = "_id";
    public static final String COL_PACKAGE = "package_name";
    public static final String COL_APP_LABEL = "app_label";
    public static final String COL_TITLE = "title";
    public static final String COL_TEXT = "text";
    public static final String COL_TIMESTAMP = "timestamp";

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_PACKAGE + " TEXT, " +
                COL_APP_LABEL + " TEXT, " +
                COL_TITLE + " TEXT, " +
                COL_TEXT + " TEXT, " +
                COL_TIMESTAMP + " INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public void insert(String packageName, String appLabel, String title, String text, long timestamp) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_PACKAGE, packageName);
        cv.put(COL_APP_LABEL, appLabel);
        cv.put(COL_TITLE, title);
        cv.put(COL_TEXT, text);
        cv.put(COL_TIMESTAMP, timestamp);
        db.insert(TABLE, null, cv);
    }

    public List<NotifItem> getAll() {
        List<NotifItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE, null, null, null, null, null, COL_TIMESTAMP + " DESC");
        while (c.moveToNext()) {
            list.add(new NotifItem(
                    c.getLong(c.getColumnIndexOrThrow(COL_ID)),
                    c.getString(c.getColumnIndexOrThrow(COL_PACKAGE)),
                    c.getString(c.getColumnIndexOrThrow(COL_APP_LABEL)),
                    c.getString(c.getColumnIndexOrThrow(COL_TITLE)),
                    c.getString(c.getColumnIndexOrThrow(COL_TEXT)),
                    c.getLong(c.getColumnIndexOrThrow(COL_TIMESTAMP))
            ));
        }
        c.close();
        return list;
    }

    public void clearAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE, null, null);
    }
}
