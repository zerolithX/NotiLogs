package com.botstoredata.notiflogger;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/**
 * Exports the notification log to a .xls file. To avoid pulling in a heavy
 * spreadsheet library (Apache POI is not friendly on Android), this writes
 * an HTML table saved with an .xls extension - Excel, Google Sheets and
 * LibreOffice Calc all open this format natively as a real spreadsheet.
 */
public class ExportUtil {

    public static Uri exportToXls(Context context, List<NotifItem> items) throws IOException {
        File dir = new File(context.getExternalFilesDir(null), "exports");
        if (!dir.exists()) dir.mkdirs();

        String fileName = "notiflogger_export_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis()) +
                ".xls";
        File file = new File(dir, fileName);

        SimpleDateFormat rowFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

        try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8")) {
            writer.write("<html><head><meta charset=\"UTF-8\"></head><body>");
            writer.write("<table border=\"1\">");
            writer.write("<tr>" +
                    "<th>App</th>" +
                    "<th>Package</th>" +
                    "<th>Title</th>" +
                    "<th>Text</th>" +
                    "<th>Date/Time</th>" +
                    "</tr>");
            for (NotifItem item : items) {
                writer.write("<tr>");
                writer.write("<td>" + escape(item.appLabel) + "</td>");
                writer.write("<td>" + escape(item.packageName) + "</td>");
                writer.write("<td>" + escape(item.title) + "</td>");
                writer.write("<td>" + escape(item.text) + "</td>");
                writer.write("<td>" + rowFmt.format(item.timestamp) + "</td>");
                writer.write("</tr>");
            }
            writer.write("</table></body></html>");
        }

        return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
    }

    public static Intent shareIntent(Context context, Uri uri) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/vnd.ms-excel");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return Intent.createChooser(intent, "Save / share export");
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }
}
