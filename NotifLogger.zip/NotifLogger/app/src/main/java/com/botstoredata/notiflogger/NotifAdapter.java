package com.botstoredata.notiflogger;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class NotifAdapter extends RecyclerView.Adapter<NotifAdapter.VH> {

    private final List<NotifItem> items;
    private final SimpleDateFormat fmt = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());

    public NotifAdapter(List<NotifItem> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        NotifItem item = items.get(position);
        holder.tvApp.setText(!TextUtils.isEmpty(item.appLabel) ? item.appLabel : item.packageName);
        holder.tvTitle.setText(item.title);
        holder.tvText.setText(item.text);
        holder.tvTime.setText(fmt.format(item.timestamp));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvApp, tvTitle, tvText, tvTime;

        VH(View itemView) {
            super(itemView);
            tvApp = itemView.findViewById(R.id.tvApp);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvText = itemView.findViewById(R.id.tvText);
            tvTime = itemView.findViewById(R.id.tvTime);
        }
    }
}
