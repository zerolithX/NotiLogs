package com.botstoredata.notiflogger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DbHelper dbHelper;
    private NotifAdapter adapter;
    private RecyclerView recyclerView;
    private TextView emptyState;

    private final BroadcastReceiver refreshReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refreshList();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DbHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        emptyState = findViewById(R.id.emptyState);

        Button btnGrantAccess = findViewById(R.id.btnGrantAccess);
        ImageButton btnExport = findViewById(R.id.btnExport);
        ImageButton btnClear = findViewById(R.id.btnClear);

        btnGrantAccess.setOnClickListener(v ->
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));

        btnExport.setOnClickListener(v -> exportLog());

        btnClear.setOnClickListener(v -> {
            dbHelper.clearAll();
            refreshList();
        });

        refreshList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(NotifListenerService.ACTION_NOTIF_LOGGED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(this, refreshReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(refreshReceiver, filter);
        }
        refreshList();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(refreshReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void refreshList() {
        List<NotifItem> items = dbHelper.getAll();
        adapter = new NotifAdapter(items);
        recyclerView.setAdapter(adapter);
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void exportLog() {
        List<NotifItem> items = dbHelper.getAll();
        if (items.isEmpty()) {
            Toast.makeText(this, "Nothing to export yet", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Uri uri = ExportUtil.exportToXls(this, items);
            startActivity(ExportUtil.shareIntent(this, uri));
        } catch (IOException e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
